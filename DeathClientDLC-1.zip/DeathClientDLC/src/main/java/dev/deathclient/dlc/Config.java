package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

/** Named presets (".cfg" in chat): module on/off state, their settings, keybinds and the active theme. */
final class Config {
    private static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc/configs");
    private static String currentName = "default";

    private Config() {}

    static String currentName() { return currentName; }

    static List<String> list() {
        if (!Files.isDirectory(DIR)) return List.of();
        try (var s = Files.list(DIR)) {
            return s.map(p -> p.getFileName().toString())
                    .filter(n -> n.endsWith(".properties"))
                    .map(n -> n.substring(0, n.length() - ".properties".length()))
                    .sorted()
                    .collect(Collectors.toList());
        } catch (IOException e) {
            return List.of();
        }
    }

    static void save(String name) {
        Properties p = new Properties();
        p.setProperty("theme", Integer.toString(Theme.current().index()));
        p.setProperty("menu.key", Integer.toString(Binds.menuKey()));
        for (Module m : ModuleManager.all()) {
            String key = sanitize(m.getName());
            p.setProperty(key + ".enabled", m.isEnabled() ? "1" : "0");
            p.setProperty(key + ".key", Integer.toString(m.getKey()));
            for (Setting s : m.getSettings()) {
                if (s instanceof BoolSetting b) p.setProperty(key + "." + sanitize(s.name), b.get() ? "1" : "0");
                else if (s instanceof NumberSetting n) p.setProperty(key + "." + sanitize(s.name), Double.toString(n.get()));
            }
        }
        try {
            Files.createDirectories(DIR);
            try (var out = Files.newOutputStream(DIR.resolve(name + ".properties"))) {
                p.store(out, "DeathClientDLC config: " + name);
            }
            currentName = name;
        } catch (IOException ignored) {}
    }

    static boolean load(String name) {
        Path file = DIR.resolve(name + ".properties");
        if (!Files.exists(file)) return false;
        Properties p = new Properties();
        try (var in = Files.newInputStream(file)) {
            p.load(in);
        } catch (IOException e) {
            return false;
        }
        String theme = p.getProperty("theme");
        if (theme != null) try { Theme.set(Integer.parseInt(theme.trim())); } catch (NumberFormatException ignored) {}
        String menuKey = p.getProperty("menu.key");
        if (menuKey != null) try { Binds.setMenuKey(Integer.parseInt(menuKey.trim())); } catch (NumberFormatException ignored) {}

        for (Module m : ModuleManager.all()) {
            String key = sanitize(m.getName());
            String en = p.getProperty(key + ".enabled");
            if (en != null && en.equals("1") != m.isEnabled()) m.toggle();
            String k = p.getProperty(key + ".key");
            if (k != null) try { m.setKey(Integer.parseInt(k.trim())); } catch (NumberFormatException ignored) {}
            for (Setting s : m.getSettings()) {
                String v = p.getProperty(key + "." + sanitize(s.name));
                if (v == null) continue;
                try {
                    if (s instanceof BoolSetting b) b.set(v.equals("1"));
                    else if (s instanceof NumberSetting n) n.set(Double.parseDouble(v.trim()));
                } catch (NumberFormatException ignored) {}
            }
        }
        currentName = name;
        Binds.save();
        return true;
    }

    static boolean delete(String name) {
        try {
            boolean existed = Files.deleteIfExists(DIR.resolve(name + ".properties"));
            if (existed && currentName.equals(name)) currentName = "default";
            return existed;
        } catch (IOException e) {
            return false;
        }
    }

    private static String sanitize(String s) { return s.toLowerCase().replace(' ', '_'); }
}
