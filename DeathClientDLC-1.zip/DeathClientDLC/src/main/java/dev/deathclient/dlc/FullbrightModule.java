package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Client-side night vision. Disabling also removes a real night vision effect. */
public class FullbrightModule extends Module {
    public FullbrightModule() { super("Fullbright", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (!p.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000000, 0, false, false, false));
        }
    }

    @Override
    protected void onDisable() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p != null) p.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }
}
