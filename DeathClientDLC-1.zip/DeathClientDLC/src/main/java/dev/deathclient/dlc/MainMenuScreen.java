package dev.deathclient.dlc;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;

/** Replacement title screen: background, title and a column of buttons on the right. */
public class MainMenuScreen extends Screen {
    private static final int BW = 150, BH = 24, GAP = 6;
    private static final int R = 4;
    private static final int NORMAL = 0xE0303030, WHITE = 0xFFFFFFFF;

    private record Item(String label, Runnable action) {}

    private final List<Item> items = new ArrayList<>();

    public MainMenuScreen() { super(Text.literal("DeathClientDLC")); }

    @Override
    protected void init() {
        items.clear();
        items.add(new Item("Singleplayer", () -> client.setScreen(new SelectWorldScreen(this))));
        items.add(new Item("Multiplayer", () -> client.setScreen(new MultiplayerScreen(this))));
        items.add(new Item("Settings", () -> client.setScreen(new OptionsScreen(this, client.options))));
        items.add(new Item("Cheat Menu", () -> client.setScreen(new ClickGuiScreen())));
        items.add(new Item("Quit", () -> client.scheduleStop()));
    }

    private int buttonX() { return width - BW - (int) (width * 0.24); }

    private int buttonY(int index) {
        int total = items.size() * BH + (items.size() - 1) * GAP;
        int y0 = Math.max(Ui.TITLE_TOP + Ui.titleHeight() + 12, (height - total) / 2 + 15);
        return y0 + index * (BH + GAP);
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        Ui.drawBackground(ctx, width, height);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        Ui.drawTitle(ctx, width);
        int x = buttonX();
        for (int i = 0; i < items.size(); i++) {
            int y = buttonY(i);
            String label = items.get(i).label();
            ClickGuiScreen.rect(ctx, x, y, BW, BH, in(mx, my, x, y, BW, BH) ? Theme.current().accent() : NORMAL, true, true);
            ctx.drawTextWithShadow(textRenderer, label, x + (BW - textRenderer.getWidth(label)) / 2, y + (BH - 8) / 2, WHITE);
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0) {
            int x = buttonX();
            for (int i = 0; i < items.size(); i++) {
                if (in(click.x(), click.y(), x, buttonY(i), BW, BH)) {
                    items.get(i).action().run();
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }
}
