package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

/** Client-side glow outline through walls (sets the entity glowing flag locally). */
public class GlowEspModule extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 64, 8, 128, 8));
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting hostile = add(new BoolSetting("Hostile", true));
    public final BoolSetting passive = add(new BoolSetting("Passive", false));
    public final BoolSetting items = add(new BoolSetting("Items", false));

    private final Set<Entity> glowing = Collections.newSetFromMap(new IdentityHashMap<>());

    public GlowEspModule() { super("Glow ESP", Category.RENDER); }

    private boolean matches(Entity e) {
        if (e instanceof PlayerEntity) return players.get();
        if (e instanceof HostileEntity) return hostile.get();
        if (e instanceof LivingEntity) return passive.get();
        if (e instanceof ItemEntity) return items.get();
        return false;
    }

    @Override
    public void onTick(MinecraftClient c) {
        glowing.removeIf(Entity::isRemoved);
        double r = range.get();
        for (Entity e : c.world.getEntities()) {
            if (e == c.player) continue;
            if (matches(e) && c.player.distanceTo(e) <= r) {
                if (glowing.add(e)) e.setGlowing(true);
            } else if (glowing.remove(e)) {
                e.setGlowing(false);
            }
        }
    }

    @Override
    protected void onDisable() {
        for (Entity e : glowing) e.setGlowing(false);
        glowing.clear();
    }
}
